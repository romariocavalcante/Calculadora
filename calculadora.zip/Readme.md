#Tutorial

1 - Use o arquivo 'script.js' para fazer o desafio.
2 - No arquivo 'calculadora.html' você precisará adicionar somente um 'id="nomedatag"' para indicar a tag que vai receber o código javascript, ou o evento 'onclick="nomedafunção"' para que seja ativada a função desejada.